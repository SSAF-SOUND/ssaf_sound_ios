//
//  APIManger.swift
//  SSAFSound
//
//  Created by 서원지 on 2023/07/13.
//

import Foundation

public enum APIManger {
    
 //MARK: -  여기에  api  리스트 만드르면  됩낟 
}

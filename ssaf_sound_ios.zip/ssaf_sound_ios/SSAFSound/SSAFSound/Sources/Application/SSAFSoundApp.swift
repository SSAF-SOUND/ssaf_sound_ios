//
//  SSAFSoundApp.swift
//  SSAFSound
//
//  Created by Subeen on 2023/07/12.
//

import SwiftUI

@main
struct SSAFSoundApp: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}

//
//  Config.swift
//  SSAFSound
//
//  Created by 서원지 on 2023/07/13.
//

import Foundation

public class Config {
    static let Release = false
}
